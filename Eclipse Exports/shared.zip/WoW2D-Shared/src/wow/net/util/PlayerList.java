package wow.net.util;

/**
 * A class for each player in a player list.
 * @author Xolitude
 *
 */
public class PlayerList {

	public String CharacterName;
	public String CharacterRace;
	public float X, Y;
	public int Direction;
}
