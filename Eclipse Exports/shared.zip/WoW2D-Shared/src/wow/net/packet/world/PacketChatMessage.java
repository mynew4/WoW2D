package wow.net.packet.world;

/**
 * Chat message packet values.
 * @author Xolitude (October 26, 2018)
 *
 */
public class PacketChatMessage {

	public String Message;
}
