package wow.net.packet.world;

/**
 * Chat message packet to all values.
 * @author Xolitude (October 26, 2018)
 *
 */
public class PacketChatMessageToAll {

	public String Username;
	public String ChatMessage;
}
