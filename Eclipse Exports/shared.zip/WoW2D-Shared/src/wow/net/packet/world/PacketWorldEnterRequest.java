package wow.net.packet.world;

/**
 * World enter packet values.
 * @author Xolitude (October 26, 2018)
 *
 */
public class PacketWorldEnterRequest {

	public String AccountName;
	public String CharacterName;
}
