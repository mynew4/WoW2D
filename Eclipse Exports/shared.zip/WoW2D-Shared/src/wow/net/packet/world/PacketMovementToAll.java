package wow.net.packet.world;

/**
 * Movement to all packet values.
 * @author Xolitude (October 26, 2018)
 *
 */
public class PacketMovementToAll {

	public String CharacterName;
	public float X;
	public float Y;
	public int Direction;
	public boolean isMoving;
}
