package wow.net.packet.world;

/**
 * Movement packet values: C->S
 * @author Xolitude (October 29, 2018)
 *
 */
public class PacketMovement_C {
	
	public int Direction;
	public boolean isMoving;
}
