package wow.net.packet.world;

/**
 * World disconnect to all packet values.
 * @author Xolitude (October 26, 2018)
 *
 */
public class PacketWorldDisconnectToAll {

	public String CharacterName;
}
