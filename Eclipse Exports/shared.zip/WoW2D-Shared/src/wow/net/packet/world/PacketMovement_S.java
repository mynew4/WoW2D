package wow.net.packet.world;

/**
 * Movement packet values: S->C
 * @author Xolitude (October 29, 2018)
 *
 */
public class PacketMovement_S {

	public float X;
	public float Y;
}
