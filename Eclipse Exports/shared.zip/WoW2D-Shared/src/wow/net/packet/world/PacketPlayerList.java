package wow.net.packet.world;

import java.util.LinkedList;

import wow.net.util.PlayerList;

/**
 * Player list packet values.
 * @author Xolitude (October 26, 2018)
 *
 */
public class PacketPlayerList {

	public LinkedList<PlayerList> PlayerList;
}
