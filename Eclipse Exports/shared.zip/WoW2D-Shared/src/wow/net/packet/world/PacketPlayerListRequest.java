package wow.net.packet.world;

/**
 * Player list packet request values.
 * @author Xolitude (October 26, 2018)
 *
 */
public class PacketPlayerListRequest {}
