package wow.net.packet.world;

/**
 * GM update packet values.
 * @author Xolitude (October 26, 2018)
 *
 */
public class PacketGMUpdate {

	public String Name;
	public boolean isGM;
}
