package wow.net.packet.logon;

/**
 * Character creation packet response values.
 * @author Xolitude (October 26, 2018)
 *
 */
public class PacketCharCreateResponse {

	public int Code;
}
