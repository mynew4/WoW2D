package wow.net.packet.logon;

/**
 * Character request packet values.
 * @author Xolitude (October 26, 2018)
 *
 */
public class PacketCharsRequest {

	public String AccountName;
	public int RealmID;
}
