package wow.net.packet.logon;

/**
 * Character request packet response values.
 * @author Xolitude (October 26, 2018)
 *
 */
public class PacketCharsResponse {

	public String Name;
}
