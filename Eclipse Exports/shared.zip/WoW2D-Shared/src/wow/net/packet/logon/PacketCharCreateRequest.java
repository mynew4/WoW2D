package wow.net.packet.logon;

/**
 * Character creation packet values.
 * @author Xolitude (October 26, 2018)
 *
 */
public class PacketCharCreateRequest {

	public String AccountName;
	public int RealmID;
	public String Name;
}
