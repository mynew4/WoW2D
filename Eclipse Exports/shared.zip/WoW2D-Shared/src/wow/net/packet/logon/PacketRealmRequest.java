package wow.net.packet.logon;

/**
 * Realm packet values.
 * @author Xolitude (October 26, 2018)
 *
 */
public class PacketRealmRequest {

	public int Code = 10;
}
