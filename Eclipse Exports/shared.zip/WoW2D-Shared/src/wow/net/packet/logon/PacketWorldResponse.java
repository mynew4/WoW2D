package wow.net.packet.logon;

/**
 * World packet response values.
 * @author Xolitude (October 26, 2018)
 *
 */
public class PacketWorldResponse {}
