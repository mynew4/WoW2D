package wow.net.packet.logon;

/**
 * Login packet values.
 * @author Xolitude (October 26, 2018)
 *
 */
public class PacketLogin {

	public String Username;
	public String Password;
}
