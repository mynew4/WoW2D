package wow.net.packet.logon;

/**
 * Character deletion packet values.
 * @author Xolitude (October 26, 2018)
 *
 */
public class PacketCharDeleteRequest {

	public String AccountName;
	public String Name;
	public int RealmID;
}
