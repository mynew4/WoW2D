package wow.net.packet.logon;

/**
 * Login packet response values.
 * @author Xolitude (October 26, 2018)
 *
 */
public class PacketLoginResponse {

	public int Code;
}
