package wow.net.packet.logon;

/**
 * Something to signify the end of the character list.
 * @author Xolitude (October 26, 2018)
 *
 */
public class PacketCharsComplete {}
