package wow.game.objects.mob.player.race;

import wow.game.WoW.RaceType;

/**
 * The forsaken race's class.
 * @author Xolitude (October 26, 2018)
 *
 */
public class RaceUndead extends IRace {

	public RaceUndead() {
		super(RaceType.Undead);
	}
}
